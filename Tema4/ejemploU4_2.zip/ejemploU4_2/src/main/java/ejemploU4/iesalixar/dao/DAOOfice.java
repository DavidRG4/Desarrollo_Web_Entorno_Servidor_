package ejemploU4.iesalixar.dao;

import java.util.List;

import ejemploU4.iesalixar.model.Oficina;

public interface DAOOfice {

	public List<Oficina> getAllOficina();

}
