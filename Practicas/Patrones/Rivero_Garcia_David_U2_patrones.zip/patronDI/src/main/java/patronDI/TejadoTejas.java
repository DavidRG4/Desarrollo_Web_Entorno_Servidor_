package patronDI;

public class TejadoTejas extends Tejado {
	public TejadoTejas() {
		// TODO Auto-generated constructor stub
	}
	public void name() {
		System.out.println("Soy las tejas que dan soporte");
	}
	@Override
	public String toString() {
		return "Tejado";
	}
	
}
