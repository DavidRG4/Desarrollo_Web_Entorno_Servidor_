package patronDI;

public class Tejado {
	public Tejado() {
	}

	public void darSoporte() {
		System.out.println("Cubro la casa");
	}
	
}
