package org.iesalixar.servidor.dto;

public class AsignaturaDTO {
private long IDProfesor;
private long IDAsignatura;

public AsignaturaDTO() {
	// TODO Auto-generated constructor stub
}

public long getIDProfesor() {
	return IDProfesor;
}

public void setIDProfesor(long iDProfesor) {
	IDProfesor = iDProfesor;
}

public long getIDAsignatura() {
	return IDAsignatura;
}

public void setIDAsignatura(long iDAsignatura) {
	IDAsignatura = iDAsignatura;
}

}
